package projetoFinal;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/*
 * @author Gustavo Travaini Chinalia
 */

//Classe para criar o objeto Imovel
public class Imovel {
    
    //Atributos do Imovel
    String nome;
    String descricao;
    String categoria;
    String tipo;
    double valor;
    
    //Criação da lista de Imóveis
    static List<Imovel> imoveis = new ArrayList();
    
    //Construtor Padrão
    public Imovel(){
    }
    
    //Construtor Sobrecarregado
    public Imovel(String nome, String descricao, String categoria, String tipo, double valor){
        this.nome = nome;
        this.descricao = descricao;
        this.categoria = categoria;
        this.tipo = tipo;
        this.valor = valor;
    }
    
    //Métodos Setter e Getter
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    
    //Função para adicionar Imovel na lista 
    public void adicionar(Imovel i){
        
        Imovel novo = i;//Objeto para armazenar as informações recebidas
        imoveis.add(novo); //Adiciona o novo objeto na lista
        
        //Mensagem de confirmação
        JOptionPane.showMessageDialog(null, "Cadastro Concluído !", "Cadastro",JOptionPane.INFORMATION_MESSAGE);
       
        FormVisualizar fv = new FormVisualizar(imoveis);
        //Exibe o FormVisualizar
        fv.setVisible(true);
        
    }
   
    public void exibirTabela(){
        //Passa a lista de imoveis para o FormVisualizar
        FormVisualizar fv = new FormVisualizar(imoveis);
        //Exibe o FormVisualizar
        fv.setVisible(true);
    }
}
